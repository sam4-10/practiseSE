package com.bankoffairfield.customeraccountsmgmtapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = {"com.bankoffairfield.customeraccountsmgmtapp"})
public class CustomeraccountsmgmtappApplication {

    public static void main(String[] args) {
        SpringApplication.run(CustomeraccountsmgmtappApplication.class, args);
    }

}
