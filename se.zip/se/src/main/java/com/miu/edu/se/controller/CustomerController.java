package com.miu.edu.se.controller;

import com.miu.edu.se.model.Customer;
import com.miu.edu.se.service.CustomerService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;

@Controller
@RequestMapping(value = {"/cadman/customer"})
public class CustomerController {

    private CustomerService customerService;

    public CustomerController(CustomerService customerService) {
        this.customerService = customerService;
    }

    @GetMapping(value = {"/list"})
    public ModelAndView listCustomers() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("customers", customerService.getCustomers());
        modelAndView.setViewName("home/list");
        return modelAndView;
    }

    @GetMapping(value = {"/customers/new"})
    public String addCustomer(Model model) {
        model.addAttribute("customer", new Customer());
        return "home/new";
    }

    @PostMapping(value = {"/customers/new"})
    public String saveCustomer(Model model, @Valid @ModelAttribute("customer") Customer customer,
                               BindingResult result) {
        model.addAttribute("customer", customer);
        if (result.hasErrors()) {
            return "home/new";
        }

        customerService.registerNewCustomer(customer);

        return "redirect:/cadman/customer/list";

    }


}