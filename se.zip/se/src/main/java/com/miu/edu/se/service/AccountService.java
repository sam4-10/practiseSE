package com.miu.edu.se.service;



import com.miu.edu.se.model.Account;

import java.util.List;

public interface AccountService {


//    public abstract Book saveBook(Book book);
//    public abstract Book getBookById(Long bookId);
//    public abstract void deleteBookById(Long bookId);
//    public abstract List<Book> searchBooks(String searchString);

    List<Account> getAccounts();

    Account saveAccount(Account account);
}
