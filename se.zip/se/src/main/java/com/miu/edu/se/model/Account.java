package com.miu.edu.se.model;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.NumberFormat;

import javax.persistence.*;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;
@Entity
@Table(name = "account")
public class Account {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long accountId;
    @Column(nullable = false, unique = true)
    @NotNull(message = "accountNumber  is required")
    @NotBlank(message = "accountNumber  cannot be empty or blank spaces")
    private String accountNumber;

    @NotNull(message = "*accounttype  is required")
    @NotBlank(message = "* accounttype  is required")
    private String accounttype;

    @NotNull(message = "* Date oppened is required")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate dateOpened;

    @NotNull(message = "* balance is required")
    @Digits(integer = 9, fraction = 2, message = "* balance must be a numeric/monetary amount in decimal (money) format as 'xxx.xx'")
    @NumberFormat(pattern = "#,###.##")
    private  double balance;




    @ManyToOne()
    @JoinColumn(name = "customerId", nullable = false)
    @NotNull(message = "* customer is required")
    private Customer customer;

    public Account(Long accountId, @NotNull(message = "accountNumber  is required") @NotBlank(message = "accountNumber  cannot be empty or blank spaces") String accountNumber, @NotNull(message = "*accounttype  is required") @NotBlank(message = "* accounttype  is required") String accounttype, @NotNull(message = "* Date oppened is required") LocalDate dateOpened, @NotNull(message = "* balance is required") @Digits(integer = 9, fraction = 2, message = "* balance must be a numeric/monetary amount in decimal (money) format as 'xxx.xx'") double balance, Customer customer) {
        this.accountId = accountId;
        this.accountNumber = accountNumber;
        this.accounttype = accounttype;
        this.dateOpened = dateOpened;
        this.balance = balance;
        this.customer = customer;
    }

    public Account(){

    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getAccounttype() {
        return accounttype;
    }

    public void setAccounttype(String accounttype) {
        this.accounttype = accounttype;
    }

    public LocalDate getDateOpened() {
        return dateOpened;
    }

    public void setDateOpened(LocalDate dateOpened) {
        this.dateOpened = dateOpened;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
}
