package com.miu.edu.se.service;


import com.miu.edu.se.model.Customer;

public interface CustomerService {
    Object getCustomers();

    void registerNewCustomer(Customer customer);

//    public abstract List<Book> getBooks();
//    public abstract Book saveBook(Book book);
//    public abstract Book getBookById(Long bookId);
//    public abstract void deleteBookById(Long bookId);
//    public abstract List<Book> searchBooks(String searchString);

}
