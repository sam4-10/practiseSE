package com.miu.edu.se.controller;


import com.miu.edu.se.model.Account;
import com.miu.edu.se.model.Customer;
import com.miu.edu.se.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;
import java.util.List;

@Controller
public class AccountController {

@Autowired
    private AccountService accountService;

//    @Autowired


    @GetMapping(value = {"/account/list"})
    public ModelAndView listBooks() {
        var modelAndView = new ModelAndView();
        List<Account> accounts = accountService.getAccounts();
        modelAndView.addObject("accounts", accounts);
        modelAndView.setViewName("account/list");
        return modelAndView;
    }

    @GetMapping(value = {"/account/new"})
    public String displayNewAccountForm(Model model) {

       Customer customer = new Customer();
       Account account = new Account();
       account.setCustomer(customer);
        model.addAttribute("account", account);
        model.addAttribute("account", account);
        return "account/new";
    }

    @PostMapping(value = {"/account/new"})
    public String addNewAccount(@Valid
                             @ModelAttribute("account") Account account,
                             BindingResult bindingResult,
                             Model model) {
        if(bindingResult.hasErrors()) {
            model.addAttribute("errors", bindingResult.getAllErrors());
            return "account/new";
        }
        System.out.println("account post");
        account = accountService.saveAccount(account);
        return "redirect:/account/list";
    }



}
