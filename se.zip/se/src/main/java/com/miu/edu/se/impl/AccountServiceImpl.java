package com.miu.edu.se.impl;

import com.miu.edu.se.model.Account;
import com.miu.edu.se.repository.AccountRepository;
import com.miu.edu.se.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AccountServiceImpl implements AccountService {

    @Autowired
    private AccountRepository accountRepository;


    @Override
    public List<Account> getAccounts() {
        return accountRepository.findAll();
    }

    @Override
    public Account saveAccount(Account account) {
        return  accountRepository.save(account);

    }


}
