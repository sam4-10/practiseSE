package com.miu.edu.se.impl;

import com.miu.edu.se.model.Account;
import com.miu.edu.se.model.Customer;
import com.miu.edu.se.repository.AccountRepository;
import com.miu.edu.se.repository.CustomerRepository;
import com.miu.edu.se.service.AccountService;
import com.miu.edu.se.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.awt.print.Book;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;

@Service
public class CustomerServiceImpl implements CustomerService {

    @Autowired
    private CustomerRepository customerRepository;




    @Override
    public Object getCustomers() {
        return customerRepository.findAll();
    }

    @Override
    public void registerNewCustomer(Customer customer) {
             customerRepository.save(customer);
    }
}
